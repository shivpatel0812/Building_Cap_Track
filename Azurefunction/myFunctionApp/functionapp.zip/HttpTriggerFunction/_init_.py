import logging
import azure.functions as func
from pymongo import MongoClient

# Function to establish a connection to MongoDB (CosmosDB Mongo API)
def get_mongo_client():
    # Hardcoded MongoDB connection string with password
    mongo_uri = "mongodb+srv://shiv12:Basketball!!998@mlprojectcapacity.mongocluster.cosmos.azure.com/?tls=true&authMechanism=SCRAM-SHA-256&retrywrites=false&maxIdleTimeMS=120000"
    
    logging.info(f"Connecting to MongoDB with URI: {mongo_uri}")
    
    try:
        # Create MongoDB client with TLS enabled
        client = MongoClient(mongo_uri, tls=True, tlsAllowInvalidCertificates=True)
        
        # Ping the MongoDB server to check the connection
        client.admin.command('ping')  # Verifies that the server is accessible
        logging.info("MongoDB connection successful")
    except Exception as e:
        logging.error(f"MongoDB connection failed: {e}")
        raise
    
    return client

# The Azure Function that gets triggered
def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('MongoDB connection attempt via Azure Function.')

    try:
        # Attempt to connect to MongoDB
        client = get_mongo_client()
        return func.HttpResponse("Mongo connected", status_code=200)
    except Exception as e:
        return func.HttpResponse(f"Mongo connection failed: {str(e)}", status_code=500)
