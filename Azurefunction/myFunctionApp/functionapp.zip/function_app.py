import azure.functions as func

# This initializes the Azure Function App
app = func.FunctionApp()
